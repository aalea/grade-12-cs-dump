/*
 * @author Aalea
 * 
 * Object that represents the decision making of Player 2
 */
public class Player2AI implements AIInterface{

	public Player start(Player player) {
		// TODO Auto-generated method stub
		return player;
	}

	@Override
	public void plant() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void harvest() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void trade() {
		// TODO Auto-generated method stub
		
	}

}
