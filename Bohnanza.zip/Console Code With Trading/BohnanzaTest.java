
public class BohnanzaTest {

	public static void main(String[] args) {
		
		new Bohnanza();

	}

}
